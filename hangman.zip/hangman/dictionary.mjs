const dictionary = {
    wrongGuesses: "Feil gjetninger: ",
    guessPrompt: "Gjett en bokstav eller ord: ",
    winCelibration: "Hurra du gjettet ordet"
}

export default dictionary